<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'lrnhtml_db' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'z+.bE#7XZdb4t-Rpsq7wR-xfV+j;MOcnB#Zatq0`#1x[hT_DmPWpcnzkgp?&aMlF' );
define( 'SECURE_AUTH_KEY',  'pYR(Q|M<L~PEXgh>_va8p@3-L(Fst;N9n=*`,bUzd*h`$LsO9J^>l(2nSMH$lS^ ' );
define( 'LOGGED_IN_KEY',    '!^Sv`f,+ZG6-f%iXGzzo!-aR%</re R.-LDwCHO13L?*H`Fd]rt3QwWqd3-1eaFH' );
define( 'NONCE_KEY',        'x:oas+q1ue]J{8 ^detl|I~>.yue,^Z`3+XW%Nn$TGUAk`4jyXeN-h*wNrg{^1kK' );
define( 'AUTH_SALT',        '``%xt,)E<Gw>>mojKOo$=MPm4VtYs1wSxH*:@p~ozI6D/*~U+QyFDTc;|{%;*ATK' );
define( 'SECURE_AUTH_SALT', '~grYEJo+ t5hq@wW&L[b&S^q~ $;ei|`(<iM+7F#;<yy]7`t6pSe:<[V}V-O.!^D' );
define( 'LOGGED_IN_SALT',   ')@+;d0@*Kd_|zky|90vG&7XX}S|1Q 7(#zT&gShF c;NUPy}r0c1;D>c_jr)#P6v' );
define( 'NONCE_SALT',       'c6M;X$?Xd^7!Z*&2T{nqn4EH(zE$6ty=iTGZs-;86L;59>fxv<D;R(&MiHQOq$QZ' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
